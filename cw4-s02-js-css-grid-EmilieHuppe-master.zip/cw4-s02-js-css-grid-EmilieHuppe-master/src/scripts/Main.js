//Permet d'importer une class
import Image from './Image';
// Vous êtes ici
class Main {
  constructor() {
    this.lang = document.documentElement.lang;

    this.init();

    this.nbImages = 69;
    this.ramdom = Math.floor(Math.random() * this.nbImages) + 1;
  }

  init() {
    console.log(
      `Nom du site: Initialisation de l\'interactivité - ${this.lang}`
    );

    this.button = document.querySelector('.js-button');
    this.button.addEventListener('click', this.addImage.bind(this));
  }

  addImage() {
    const imageId = Math.floor(Math.random() * this.nbImages) + 1;
    this.path = `assets/images/${imageId}.jpg`;
    let newImg = new Image(this.path);
  }
}

new Main();
