//PErmet d'exporter la class dans d'autre class
export default class Image {
  constructor(path) {
    this.path = path;
    this.posX = Math.random() * 100;
    this.posY = Math.random() * 100;
    //this.source = 'assets/images/30.jpg';
    this.initImg();
  }

  initImg() {
    let newImag = document.createElement('img');

    newImag.src = this.path;

    newImag.style.left = `${this.posX}%`;
    newImag.style.top = `${this.posY}%`;

    newImag.classList.add('student-image');

    document.querySelector('body').appendChild(newImag);
  }
}
