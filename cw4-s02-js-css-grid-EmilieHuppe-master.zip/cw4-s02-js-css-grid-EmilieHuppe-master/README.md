[capture]: _readme/exercice02-demo.png

# Semaine 02 - Exercice 01 - Introduction aux classes

Suite à la théorie de révision et d'introduction des classes, l'exercice suivant vous guidera dans la création de vos premières classes.

L'exercice consiste à faire afficher une image aléatoire dans la page lorsqu'on clique sur un bouton. L'image sera aussi positionnée de façon aléatoire dans la page.
<br><br>

## **Consigne de l'exercice**

<br>

### STRUCTURE DE BASE
- Création de la classe Main
    1. Dans le fichier `Main.js` créer une class nommée `Main`;
    1. Créer un instance de votre ***nouvelle*** classe `Main`
    1. Mettre un `console.log` avec 'Nom du site: Initialisation de l'interactivité';
    1. Si le `console.log` ne fonctionne pas à l'intérieur de votre classe c'est qu'il vous manque une méthode essentielle à la *construction* de votre classe. À vous de trouvez laquelle;
- Création d'une première méthode `init`
    1. Dans votre classe `Main` y ajouter une méthode `init()`;
    1. Déplacer le `console.log` du constructeur dans cette nouvelle méthode;
- Création d'une variable
    1. Créer une variable dans votre constructeur nommé `lang`
    1. Faire en sorte de récupéré l'attribut `lang` de la balise `<html>`
        - Vous ne pouvez **pas** utiliser `document.querySelector`
    1. Dans le `console.log` de la méthode `init` ajouter avec un `template string` la variable de langue
        - Vous devriez avoir comme résultat dans votre console -> `Nom du site: Initialisation de l'interactivité : Langue du site web - fr`
        - Si votre console affiche `undefined` au lieu de `fr`. Vous n'avez peut-être pas fait le bon choix entre une variable `let`, `const` ou `global(this)`
<br><br>
### CRÉATION D'UNE IMAGE
Dans l'optique d'être `OOP proof`, nous allons faire une classe `Image`  
1. Dans le fichier `Main.js` en dessous de votre instanciation de Main, ajouter une nouvelle classe `Image`
1. Créer un instance de votre ***nouvelle*** classe `Image`
1. Créer une variable image
    - Créer une nouvelle [élément image](https://developer.mozilla.org/en-US/docs/Web/API/Document/createElement)
    - Changer la source pour : `"assets/images/30.jpg"`
    - Ajouter une classe css `student-image` sur l'image 
1. Vous devez maintenant ajouter cette `nouvelle image` directement dans le `body`

Vous devriez maintenant avoir une image qui s'affiche dans le coin en haut de votre site web.  
<br>
### AJOUT DE L'IMAGE LORS D'UN CLICK SUR LE BOUTON
Nous allons maintenant faire en sorte qu'une image se créer chaque fois qu'on click sur le bouton de la page.
1. Supprimer la création de `l'instance Image` que vous avez fait à l'étape précedante.
2. Dans la classe `Main` :
    - Créer une méthode `addImage`
        - Créer un instance de la classe `Image`
    - Dans la méthode `init`
        - Créer une variable `button` qui selection la classe js-button
        - Ajouter sur `événement click` sur votre button qui dirige à la méthode `addImage`

Vous devriez maintenant avoir une image qui s'ajoute lorsque vous cliquez sur le bouton. `Il serait plus intéressant que l'image soit aléatoire`. *On n'est tanné de voir Paul*.
<br><br>
### DÉFI SUPPLÉMENTAIRE
- Choix de l'image aléatoire
    1. Dans la classe `Main`
        - Dans le `constructeur` créer une variable pour le nombre total d'image `totalImage` et lui donner la valeur `69`
        - Dans la méthode `addImage()` créer une variable `imageId`
            - Il faut faire des Maths maintenant, faite un console.log à chaque étape:
                - Faite en sorte d'avoir une valeur random entre `1` et le nombre total d'image(`totalImage`)
                    - Math.random() => Chiffre entre 0 et 1
                    - Multiplié par notre total d'image => chiffre entre 0 et 69
                    - Math.floor => Permet d'arrondir au plus petit
                    - \+ 1 à tout ça => Chiffre entre 1 et 69
        - Dans la méthode `addImage()` créer une variable `path`
            - Avec un template string créer une chaine de caractère qui donne quelque chose comme ça `assets/images/imageId.jpg`
        - Il faut maintenant passer la variable `path` en paramètre à notre instance Image
            - Ajouter dans le constructeur de la classe `Image` un paramètre `path`
                - `constructor(path)`
            - Passer le paramètre lors de l'instanciation de votre nouvelle image
                - `new Image(path)`
- Positionnement aléatoire de l'image
    1. Dans la classe `Image`
        - Créer une variable `posX`
            - Ajouter une valeur aléatoire entre 0 et 100
        - Répeter le point précédent pour une variable `posY`
        - Ajuster les styles left/top de votre image pour y ajouter la valeur posX/posY en %;
            - Indice ça implique des `TemplateString`  

Vous devriez maintenant avoir une nouvelle image aléatoire qui se positionne aléatoirement dans votre page.  
<br><br>
# Bravo vous avez terminé l'exercice

<br><br><br>

# Semaine 02 - Exercice 02 - Révision des CSS Grid

L'objectif de l'exercice #02 est de faire une révision des CSS Grids. Pour ce faire, vous avez le HTML de fourni et devez suivre les consignes pour recréer la capture d'écran suivante sans toucher au html.

Capture d'écran prise en 1440px de large, le chevron en arrière-plan est en position fixe (Le css est déjà fait pour celui-là).

![alt Démo de grid.html][capture]
<br><br>

## Consigne pour reproduire la maquette

1. CSS pour la `.main-grid`
   - Doit être un `CSS grid`;
   - Doit avoir une gouttière de `10px`;
   - Une hauteur de `100vh`;
   - Le template des rangées doit être de:
     - 1ère rangée: `100px`;
     - 2ieme rangée: `1fr`;
     - 3ieme rangée: `60px`;
   - Le template des colonnes doit être:
     - `3` colonnes `d'une fraction` chacune;
   - Créer ensuite des zones de template
     - 1ère rangée: `header`;
     - 2eme rangée:
       - 2 colonnes: `content`;
       - 1 colonne: `sidebar`;
     - 3ieme rangée: `footer`;
   - Créer ensuite des zones de template pour le media query `768px`:
     - N'oubliez pas pour le media query `768px`, je pense qu'on a une `variable SASS`;
     - 1ere rangée: `header`;
     - 2eme rangée: `content`;
     - 3ieme rangée: `sidebar`;
     - 4ieme rangée: `footer`;
1. CSS pour `.header`, `.content`, `.footer`
   - Doit avoir du padding de `20px` à gauche et à droite;
1. CSS pour `.header`
   - Vous devez lui assigner la `zone header`;
1. CSS pour `.content`
   - Vous devez lui assigner la `zone content`;
   - Avec un sélecteur avancé, faites en sorte que les sections qui sont précédée d'une autre section, aient une margin haut de `60px`;
1. CSS pour `.sidebar`
   - Vous devez lui assigner la `zone sidebar`;
1. CSS pour `.footer`
   - Vous devez lui assigner la `zone footer`;
   - Couleur de fond: `vert primaire`;
   - Couleur de texte: `blanc`;
   - Padding: sur tous les côtés de `20px`;
1. Mise en page du `header avec le menu`
   - Vous avez les connaissances pour reproduire la maquette sans aide;
1. CSS pour `.menu-item`
   - bordure: `2px solid vert primaire`;
   - border radius: `5px`;
   - padding haut/bas: `5px`;
   - padding gauche/droite: `10px`;
1. Mise en page du `footer`
   - Vous avez les connaissances pour reproduire la maquette sans aide;
1. Mise en page des cartes `.card`
   - Background: `blanc`;
   - border radius: `10px`;
   - Couleur des textes: `couleur primaire`;
   - Padding: sur tous les côtés de `20px`;
1. Mise en page de la section `.grid1`
   - Doit être un `CSS grid`;
   - Doit avoir une gouttière de `20px`;
   - Doit avoir un template de `3` colonnes `d'une fraction` chacune;
1. Mise en page de la section `.grid2`
   - Doit être un `CSS grid`;
   - Doit avoir une gouttière de `20px`;
   - Doit avoir un template de colonnes qui `s'auto-fit` avec un minimum de `100px` et maximum `d'une fraction`;
   - Avec de l'imbrication SCSS, ajuster les styles de `.card1`:
     - Pour qu'il s'étire sur `2` colonnes
   - Avec de l'imbrication SCSS, ajuster les styles de `.card4`:
     - Pour qu'il s'étire sur `2` rangées
1. Mise en page de la section `.grid3`
   - Doit être un `CSS grid`;
   - Doit avoir une gouttière de `20px`;
   - Doit avoir un template de `3` colonnes `d'une fraction` chacune;
   - Doit avoir un template de `2` rangées `d'une fraction` chacune;
   - Avec de l'imbrication SCSS, styler les images:
     - Hauteur: `300px`;
     - Largeur: `100%`;
     - Les images doivent `s'étirer en gardant leur ratio`;
   - Avec l'imbrication SCSS et les sélecteurs avancés, faites en sorte que la `première` et `quatrième` images s'étirent sur `deux colonnes`;
1. Mise en page de la `sidebar`
   - Avec de l'imbrication SCSS, styler l'image:
     - Hauteur: `100%`;
     - Largeur: `100%`;
     - Les images doivent `s'étirer en gardant leur ratio`;

Vous devriez maintenant avoir sensiblement la même chose que la capture d'écran
<br>

## Bravo vous avez terminé l'exercice 02

<br><br>

# Stack de développement frontend TimTools

C'est quoi un stack de développement frontend? C'est un ensemble d'outil qui permet d'automatiser certaines tâches redondantes et plus complexe afin de d'accélérer et d'optmiser le développement d'un site web ou une application.

## Après avoir cloné un projet pour la 1ère fois

- `npm install` afin d'installer les dépendances (dossier node_modules)

## Tâches

Afin de démarrer le stack de développement, utilisez les commandes suivantes dans la console ou utilisez la tâche `start`

| Commandes disponibles | Description                                                                                                 |
| :-------------------- | :---------------------------------------------------------------------------------------------------------- |
| `npm start`           | Génère un environnement de développement, démarre un serveur web et va attendre des changements de fichiers |
| `npm build`           | Compile production code                                                                                     |
